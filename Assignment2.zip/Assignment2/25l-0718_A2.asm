[org 0x100]
jmp start
obs dw 6552h,2C91h,7FA3h
numObs db 3

weights db 2,-3,-1,10
db 1,4,2,0
db -2,5,4,-5
 normscore dw 0
 susscore dw 0
 atkscore dw 0
predflag db 0
x1 dw 0
x2 dw 0
x3 dw 0

start:
mov si,obs
mov cl,[numObs]
mov ch,0
process:
mov ax,[si]
mov dx,ax
and dx,001Fh
sub dx,16
mov [x3],dx

mov dx,ax
shr dx,5
and dx,001Fh
sub dx,8
mov [x2],dx
 
mov dx,ax
shr dx,10
and dx,003Fh
sub dx,20
mov [x1],dx

mov di,10
mov bx,[x1]
mov al,[weights]
cbw
imul bx
add di,ax

mov bx,[x2]
mov al,[weights+1]
cbw
imul bx
add di,ax

mov bx,[x3]
mov al,[weights+2]
cbw
imul bx
add di,ax

mov [normscore],di
mov di,0
mov bx,[x1]
mov al,[weights+4]
cbw
imul bx
add di,ax

mov bx,[x2]
mov al,[weights+5]
cbw
imul bx
add di,ax

mov bx,[x3]
mov al,[weights+6]
cbw
imul bx
add di,ax
mov [susscore],di
mov di,-5
mov bx,[x1]
mov al,[weights+8]
cbw
imul bx
add di,ax
mov bx,[x2]
mov al,[weights+9]
cbw
imul bx
add di,ax
mov bx,[x3]
mov al,[weights+10]
cbw
imul bx
add di,ax
mov [atkscore],di
mov ax,[normscore]
mov byte [predflag],1
cmp ax,[susscore]
jg compareattack
mov ax,[susscore]
mov byte [predflag],2
compareattack:
cmp ax,[atkscore]
jg nextobservation
je nextobservation
mov ax,[atkscore]
mov byte [predflag],3
nextobservation:
add si,2
dec cx
jnz process 
mov ax,0x4C00
int 0x21 


