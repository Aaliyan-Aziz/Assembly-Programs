[org 0x100]
jmp start

;DATA

title: db 'TEXT VIEWER',0
line1: db '8088 Assembly Language Text Viewer',0
line2: db 'String instruction: LODSB STOSW MOVSW',0
line3: db 'Stack parameters and BP addressing',0
line4 db 'Search Keyword: STACK',0
line5: db 'Scrolling inside the viewport window',0
line6: db 'Video memory segment is B800h',0

keyword: db 'STACK',0
status_text: db 'Total Matches Found: ',0
status_tail: db '| viewport Status: ACTIVE' ,0
matches: dw 0
cur_col dw 0

;MAIN
start:
push cs
pop ds

mov ax,0B800h
mov es,ax
;Clear Screen
xor di,di 
mov ax,0720h
mov cx,2000
cld
rep STOSW

;draw window
mov ax,3
push ax
mov ax,8
push ax
mov ax,21
push ax
mov ax,72
push ax
mov ax,07h
push ax
call draw_window

;print screen
mov ax,title  ;String
push ax
mov ax,3        ;row
push ax
mov ax,35       ;column
push ax
mov ax,1Eh       ;attribute
push ax
call print_string

mov ax,line1  ;String
push ax
mov ax,5        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string

mov ax,line2  ;String
push ax
mov ax,7        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string

mov ax,line3  ;String
push ax
mov ax,9        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string

mov ax,line4  ;String
push ax
mov ax,11        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string

mov ax,line5  ;String
push ax
mov ax,13        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string

mov ax,line6  ;String
push ax
mov ax,15        ;row
push ax
mov ax,10       ;column
push ax
mov ax,07h       ;attribute
push ax
call print_string


xor ah,ah
int 16h

;scroll window up
mov ax,1 ;N
push ax
mov ax,72 ;right
push ax
mov ax,21 ;bottom
push ax
mov ax,8 ;left
push ax
mov ax,3 ;top
push ax
call scroll_window_up

xor ah,ah
int 16h
;find-and-highlight
mov ax,4
push ax
mov ax,10
push ax
mov ax,20
push ax
mov ax,70
push ax
mov ax,keyword
push ax
mov ax,0CEh
push ax
call find_and_highlight
mov [matches],ax

mov ax,status_text
push ax
mov ax,23
push ax
mov ax,8
push ax
mov ax,0Fh
push ax
call print_string
mov [cur_col],ax

mov ax,[matches]
push ax
mov ax,23
push ax
mov ax,[cur_col]
push ax
mov ax,0Eh
push ax
call printNum
mov [cur_col],ax

mov ax,status_tail
push ax
mov ax,23
push ax
mov ax,[cur_col]
push ax
mov ax,0Fh
push ax
call print_string

xor ah,ah
int 16h
mov ax,0x4C00
int 0x21

;Draw window
draw_window:
push bp
mov bp,sp
sub sp,4
push ax
push bx
push cx
push dx
push di
push es

mov ax,0B800h
mov es,ax
cld

mov ax,[bp+6]
sub ax,[bp+10]
dec ax
mov [bp-2],ax

mov ax,[bp+12]
mov bx,80
mul bx
add ax,[bp+10]
shl ax,1
mov di,ax
mov ah,[bp+4]
mov al,0C9h
stosw
mov cx,[bp-2]
mov al,0CDh
rep STOSW
mov al,0BBh
STOSW

;left and right border
mov ax,[bp+12]
inc ax
mov [bp-4],ax
side:
mov ax,[bp-4]
cmp ax,[bp+8]
jae bottom
mov ax,[bp-4]
mov bx,80
mul bx
add ax,[bp+10]
shl ax,1
mov di,ax
mov ah,[bp+4]
mov al,0BAh
STOSW
mov ax,[bp-2]
shl ax,1
add di,ax
mov ah,[bp+4]
mov al,0BAh
STOSW
inc word [bp-4]
jmp side
bottom:
mov ax,[bp+8]
mov bx,80
mul bx
add ax,[bp+10]
shl ax,1
mov di,ax
mov ah,[bp+4]
mov al,0C8h
STOSW
mov cx,[bp-2]
mov al,0CDh
rep STOSW
mov al,0BCh
STOSW

pop es
pop di
pop dx
pop cx
pop bx
pop ax
mov sp,bp
pop bp
ret 10

;Print String

print_string:
push bp 
mov bp,sp
push bx
push dx
push si
push di
push es
mov ax,0B800h
mov es,ax
mov ax,[bp+8]
mov bx,80
mul bx
add ax,[bp+6]
shl ax,1
mov di,ax
mov si,[bp+10]
mov dx,[bp+6]
mov ah,[bp+4]
cld
next:
LODSB
cmp al,0
je done
stosw
inc dx
jmp next
done:
mov [bp-2],dx
pop es
pop di
pop si
pop dx
pop bx

mov ax,[bp-2]
mov sp,bp
pop bp
ret 8

;Scroll window up
scroll_window_up:
push bp 
mov bp,sp
sub sp,8
push ax
push bx
push cx
push dx
push si
push di
push ds
push es
mov ax,0B800h
mov ds,ax
mov es,ax

mov ax,[bp+10]
sub ax,[bp+6]
dec ax
mov [bp-6],ax
mov ax,[bp+8]
sub ax,[bp+4]
dec ax
sub ax,[bp+12]
mov [bp-8],ax
mov ax,[bp+4]
inc ax
mov [bp-2],ax
scroll_copy_row:
cmp word [bp-8],0
jle scroll_clear_start
mov ax,[bp-2]
add ax,[bp+12]
mov [bp-4],ax
mov ax,[bp-4]
mov bx,160
mul bx
mov si,ax
mov ax,[bp+6]
inc ax
shl ax,1
add si,ax

mov ax,[bp-2]
mov bx,160
mul bx
mov di,ax
mov ax,[bp+6]
inc ax
shl ax,1
add di,ax

mov cx,[bp-6]
cld
rep MOVSW
inc word [bp-2]
dec word [bp-8]
jmp scroll_copy_row

scroll_clear_start:
mov ax,[bp+8]
sub ax,[bp+12]
mov [bp-2],ax

scroll_clear_row:
mov ax,[bp+8]
dec ax
cmp [bp-2],ax
ja scroll_done
mov ax,[bp-2]
mov bx,160
mul bx
mov di,ax
mov ax,[bp+6]
inc ax
shl ax,1
add di,ax
mov cx,[bp-6]
mov ax,072h
cld
rep STOSW
inc word [bp-2]
jmp scroll_clear_row
scroll_done:
pop es
pop ds
pop di
pop si
pop dx
pop cx
pop bx
pop ax
mov sp,BP
pop bp
ret 10

find_and_highlight:
push bp 
mov bp,sp
sub sp,8
push bx
push cx
push dx
push si
push di
push es
mov ax,0B800h
mov es,ax
cld
mov word [bp-2],0
mov word [bp-4],0
mov word [bp-6],0

mov si,[bp+6]
len:
cmp byte [si],0
je len_done
inc word [bp-4]
inc si
jmp len

len_done:
cmp word [bp-4],0
je finished
mov ax,[bp+8]
sub ax,[bp+12]
inc ax
cmp [bp-4],ax
ja finished
mov ax,[bp+8]
inc ax
sub ax,[bp-4]
shl ax,1
mov [bp-8],ax
mov ax,[bp+14]
mov [bp-2],ax
row:
mov ax,[bp-2]
cmp ax,[bp+10]
ja finished
mov bx,160
mul bx
mov di,ax
mov ax,[bp+12]
shl ax,1
add di,ax
position:
mov ax,di
mov bx,160
xor dx,dx
div bx
cmp dx,[bp-8]
ja next_row
push di
push dx
mov si,[bp+6]
mov cx,[bp-4]
compare:
cmpsb
jne no_match
inc di
loop compare
pop dx
pop di
push di
mov cx,[bp-4]
mov si,di
mov al,[bp+4]
highlight:
mov byte [es:si+1],al
add si,2
loop highlight
inc word [bp-6]
pop di
add di,2
jmp position
no_match:
pop dx
pop di
add di,2
jmp position
next_row:
inc word [bp-2]
jmp row
finished:
pop es
pop di
pop si
pop dx
pop cx
pop bx
mov ax,[bp-6]
mov sp,bp
pop bp 
ret 12

;Print number
printNum:
push bp 
mov bp,sp
sub sp,4
push bx
push dx
push di
push es

mov ax,[bp+10]
mov bx,10
xor dx,dx
div bx
mov [bp-2],dx
mov dx,[bp+6]
mov [bp-4],dx
cmp ax,0
je digit

push ax
mov ax,[bp+8]
push ax
mov ax,[bp+6]
push ax
mov ax,[bp+4]
push ax
call printNum
mov [bp-4],ax

digit:
mov ax,[bp+8]
mov bx,80
mul bx
add ax,[bp-4]
shl ax,1
mov di,ax
mov al,[bp-2]
add al,'0'
mov ah,[bp+4]
cld
STOSW
inc word [bp-4]
pop es
pop di
pop dx
pop bx
mov ax,[bp-4]
mov sp,bp
pop bp 
ret 8




